<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FileTypeDetail extends Model
{
    //
}

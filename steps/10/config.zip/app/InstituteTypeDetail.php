<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InstituteTypeDetail extends Model
{
    //
}

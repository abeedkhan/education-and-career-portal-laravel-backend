<?php

namespace App\Http\Controllers;

use App\CareerDetail;
use Illuminate\Http\Request;

class CareerDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CareerDetail  $careerDetail
     * @return \Illuminate\Http\Response
     */
    public function show(CareerDetail $careerDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CareerDetail  $careerDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(CareerDetail $careerDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CareerDetail  $careerDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CareerDetail $careerDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CareerDetail  $careerDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(CareerDetail $careerDetail)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\FileTypeDetail;
use Illuminate\Http\Request;

class FileTypeDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FileTypeDetail  $fileTypeDetail
     * @return \Illuminate\Http\Response
     */
    public function show(FileTypeDetail $fileTypeDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FileTypeDetail  $fileTypeDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(FileTypeDetail $fileTypeDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FileTypeDetail  $fileTypeDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FileTypeDetail $fileTypeDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FileTypeDetail  $fileTypeDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(FileTypeDetail $fileTypeDetail)
    {
        //
    }
}

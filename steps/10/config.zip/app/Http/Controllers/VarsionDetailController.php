<?php

namespace App\Http\Controllers;

use App\VarsionDetail;
use Illuminate\Http\Request;

class VarsionDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VarsionDetail  $varsionDetail
     * @return \Illuminate\Http\Response
     */
    public function show(VarsionDetail $varsionDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VarsionDetail  $varsionDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(VarsionDetail $varsionDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VarsionDetail  $varsionDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VarsionDetail $varsionDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VarsionDetail  $varsionDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(VarsionDetail $varsionDetail)
    {
        //
    }
}

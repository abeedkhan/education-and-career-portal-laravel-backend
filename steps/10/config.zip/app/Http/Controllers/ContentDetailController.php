<?php

namespace App\Http\Controllers;

use App\ContentDetail;
use Illuminate\Http\Request;

class ContentDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ContentDetail  $contentDetail
     * @return \Illuminate\Http\Response
     */
    public function show(ContentDetail $contentDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ContentDetail  $contentDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(ContentDetail $contentDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ContentDetail  $contentDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ContentDetail $contentDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ContentDetail  $contentDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(ContentDetail $contentDetail)
    {
        //
    }
}

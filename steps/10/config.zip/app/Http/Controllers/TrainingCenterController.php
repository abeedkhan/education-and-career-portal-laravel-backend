<?php

namespace App\Http\Controllers;

use App\TrainingCenter;
use Illuminate\Http\Request;

class TrainingCenterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TrainingCenter  $trainingCenter
     * @return \Illuminate\Http\Response
     */
    public function show(TrainingCenter $trainingCenter)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TrainingCenter  $trainingCenter
     * @return \Illuminate\Http\Response
     */
    public function edit(TrainingCenter $trainingCenter)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TrainingCenter  $trainingCenter
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TrainingCenter $trainingCenter)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TrainingCenter  $trainingCenter
     * @return \Illuminate\Http\Response
     */
    public function destroy(TrainingCenter $trainingCenter)
    {
        //
    }
}

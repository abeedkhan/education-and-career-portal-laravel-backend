<?php

namespace App\Http\Controllers;

use App\DistrictDetail;
use Illuminate\Http\Request;

class DistrictDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DistrictDetail  $districtDetail
     * @return \Illuminate\Http\Response
     */
    public function show(DistrictDetail $districtDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DistrictDetail  $districtDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(DistrictDetail $districtDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DistrictDetail  $districtDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DistrictDetail $districtDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DistrictDetail  $districtDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(DistrictDetail $districtDetail)
    {
        //
    }
}

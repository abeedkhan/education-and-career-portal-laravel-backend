<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeDetail extends Model
{
    //
}

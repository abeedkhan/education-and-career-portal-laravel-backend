<?php /* C:\localhost\neccbd\app\resources\views/index.blade.php */ ?>
<html>
<head></head>
<body>
    <h5>hello</h5>
</body>
</html>